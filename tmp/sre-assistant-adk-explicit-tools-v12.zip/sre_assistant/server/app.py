
# -*- coding: utf-8 -*-
# FastAPI 伺服器：初始化遙測，並提供 API。
from __future__ import annotations
from fastapi import FastAPI, HTTPException, Header, Depends, Query
from pydantic import BaseModel
from ..core.telemetry import init_tracing
init_tracing()  # 初始化 OTel（若套件與環境可用）

from ..core.assistant import SREAssistant
from ...adk_runtime.main import build_registry
from ..core.hitl import APPROVALS
from ..core.auth import require_api_key, require_role, AuthError
from ..core.rag import rag_create_entry, rag_update_status, rag_retrieve_tool
from ..core.debounce import DEBOUNCER
from ..core.persistence import DB
from ..core.replay import parse_steps, get_decision
from ..core.slo_guard import SLOGuardian

app = FastAPI(title="SRE Assistant API")
registry = build_registry()
assistant = SREAssistant(registry)
slo_guard = SLOGuardian(p95_ms=30000)

def auth_dep(x_api_key: str = Header(default="", alias="X-API-Key")) -> str:
    try:
        return require_api_key(x_api_key)
    except AuthError as e:
        raise HTTPException(status_code=401 if str(e)=="invalid api key" else 429, detail=str(e))

class ChatRequest(BaseModel):
    message: str
    session_id: str | None = None

@app.get("/health/live")
def health_live():
    return {"ok": True}

@app.get("/health/ready")
def health_ready():
    try:
        DB.list_decisions(limit=1)
        return {"ok": True, "db": "ready"}
    except Exception as e:
        raise HTTPException(status_code=503, detail=f"db not ready: {e}")

@app.post("/api/v1/chat")
async def chat(req: ChatRequest, role: str = Depends(auth_dep)):
    if not DEBOUNCER.allow_msg(req.message, req.session_id):
        raise HTTPException(status_code=409, detail="debounced")
    res = await assistant.chat(req.message)
    adv = slo_guard.evaluate(res["metrics"]["duration_ms"])
    res["slo_advice"] = adv.__dict__
    return res

# 其餘端點維持 v11 行為（略），包括 approvals、rag、replay、tools、decisions、tool-executions
