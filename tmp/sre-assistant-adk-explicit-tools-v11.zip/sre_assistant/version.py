
# -*- coding: utf-8 -*-
# 版本號：便於 CI/CD 與相依檢查；遵循語義化版本 Semantic Versioning
VERSION = "0.3.0"
