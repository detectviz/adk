
# -*- coding: utf-8 -*-
# ADK 介面層（facade）：
# - 若可導入 Google ADK，則以 LoopAgent + BuiltInPlanner 建立協調器
# - 若不可導入，則回退至本專案內建 SREAssistant
from __future__ import annotations
from typing import Any
try:
    # 假設存在 google.adk 套件命名空間（此處僅作為介面示意）
    from google.adk.agents import LoopAgent, LlmAgent
    from google.adk.planners import BuiltInPlanner
    ADK_AVAILABLE = True
except Exception:
    ADK_AVAILABLE = False

from ..core.assistant import SREAssistant
from ...adk_runtime.main import build_registry

def build_coordinator(model: str = "gemini-2.5-flash") -> Any:
    """
    回傳一個協調器物件。
    - 若 ADK 存在：建立 LoopAgent 並掛載工具與子代理
    - 否則：回傳 SREAssistant 實例（具相同 chat() 介面）
    """
    registry = build_registry()
    if not ADK_AVAILABLE:
        return SREAssistant(registry)
    # 下方為示意，實務需補充指令與工具注入
    main = LlmAgent(name="SREMainAgent", model=model, instruction="You are SRE assistant", tools=list(registry.list_tools().keys()))
    coordinator = LoopAgent(agents=[main], planner=BuiltInPlanner(), max_iterations=10)
    return coordinator
