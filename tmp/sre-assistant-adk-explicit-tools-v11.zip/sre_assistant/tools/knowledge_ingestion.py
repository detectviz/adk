
# -*- coding: utf-8 -*-
# 知識匯入工具：
# - 將文件或片段切成 chunks，產生向量並寫入 pgvector；同時寫入 SQLite RAG Entries 做版本管理
from __future__ import annotations
from typing import Dict, Any, List
import os, textwrap
from ..core.embeddings import Embedder
from ..core.vectorstore_pg import PgVectorStore
from ..core.rag import rag_create_entry

def _chunk(text: str, size: int = 600, overlap: int = 100) -> List[str]:
    lines = textwrap.wrap(text, width=size)
    # 簡化：直接分段，不做重疊
    return lines

def knowledge_ingestion_tool(title: str, content: str, tags: list[str] | None = None, status: str = "draft") -> Dict[str, Any]:
    entry = rag_create_entry(title, content, author="ingestion-tool", tags=tags or [], status=status)
    dsn = os.getenv("PG_DSN")  # 例如：postgresql://user:pass@host:5432/db
    if dsn:
        chunks = _chunk(content)
        embedder = Embedder()
        vecs = embedder.embed_texts(chunks)
        vs = PgVectorStore(dsn=dsn, dim=len(vecs[0]))
        vs.upsert(entry["id"], chunks, vecs, tags or [], status)
        return {"ok": True, "entry_id": entry["id"], "chunks": len(chunks), "vectorized": True}
    else:
        # 無 PG 時僅寫入 entries（FTS fallback）
        return {"ok": True, "entry_id": entry["id"], "chunks": 1, "vectorized": False}
