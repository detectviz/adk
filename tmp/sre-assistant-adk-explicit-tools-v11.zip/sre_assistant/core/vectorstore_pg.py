
# -*- coding: utf-8 -*-
# pgvector 向量庫：
# - 需要 PostgreSQL 與 pgvector 擴充（CREATE EXTENSION IF NOT EXISTS vector）
# - 若無法連線 PG，請改用既有的 FTS 檢索（由 rag.py 自動 fallback）
from __future__ import annotations
from typing import List, Dict, Any, Optional
import os

try:
    import psycopg
except Exception:
    psycopg = None

class PgVectorStore:
    def __init__(self, dsn: str, dim: int = 384):
        if psycopg is None:
            raise RuntimeError("未安裝 psycopg，無法使用 pgvector")
        self.dim = dim
        self.conn = psycopg.connect(dsn, autocommit=True)
        self._init_schema()

    def _init_schema(self):
        with self.conn.cursor() as cur:
            cur.execute("CREATE EXTENSION IF NOT EXISTS vector")
            cur.execute("""
            CREATE TABLE IF NOT EXISTS rag_chunks (
              id BIGSERIAL PRIMARY KEY,
              doc_id BIGINT,
              content TEXT NOT NULL,
              embedding vector(%s),
              tags TEXT,
              status TEXT,
              created_at TIMESTAMPTZ DEFAULT NOW()
            );
            """, (self.dim,))

    def upsert(self, doc_id: int, chunks: List[str], embeddings: List[List[float]], tags: List[str], status: str):
        with self.conn.cursor() as cur:
            for c, e in zip(chunks, embeddings):
                cur.execute(
                    "INSERT INTO rag_chunks(doc_id, content, embedding, tags, status) VALUES (%s,%s,%s,%s,%s)",
                    (doc_id, c, e, ",".join(tags), status)
                )

    def search(self, query_vec: List[float], top_k: int = 5, status: Optional[List[str]] = None) -> List[Dict[str, Any]]:
        cond = ""
        args: list[Any] = [query_vec, top_k]
        if status:
            cond = "WHERE status = ANY(%s)"
            args = [query_vec, status, top_k]
        with self.conn.cursor() as cur:
            cur.execute(
                f"SELECT id, doc_id, content, tags, status, embedding <#> %s AS distance FROM rag_chunks {cond} ORDER BY embedding <#> %s LIMIT %s",
                args
            )
            rows = cur.fetchall()
        res = []
        for r in rows:
            res.append({"id": r[0], "doc_id": r[1], "content": r[2], "tags": (r[3] or "").split(","), "status": r[4], "distance": float(r[5])})
        return res
