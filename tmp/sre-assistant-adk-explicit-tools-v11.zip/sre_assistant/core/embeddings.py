
# -*- coding: utf-8 -*-
# 嵌入器（Embeddings）：
# - 預設使用簡單 hash->向量 的本地實作，保證可離線運作
# - 若環境變數 EMBEDDER=hf 且安裝對應套件，可擴充為真實嵌入
from __future__ import annotations
from typing import List
import math, hashlib, random

def _hash_to_float(s: str) -> float:
    # 將 SHA1 轉換為 0..1 浮點
    h = hashlib.sha1(s.encode("utf-8")).hexdigest()
    return int(h[:8], 16) / 0xFFFFFFFF

class Embedder:
    def __init__(self, dim: int = 384):
        self.dim = dim
        self.mode = "hash"  # 可擴充 hf/vertex

    def embed_texts(self, texts: List[str]) -> List[List[float]]:
        # Hash-based 簡易嵌入：非語意，但可運作示例與 pgvector。
        vecs = []
        for t in texts:
            seed = int(hashlib.sha1(t.encode("utf-8")).hexdigest()[:8], 16)
            random.seed(seed)
            v = [random.random()*2-1 for _ in range(self.dim)]
            # 簡單正規化
            n = math.sqrt(sum(x*x for x in v)) or 1.0
            v = [x/n for x in v]
            vecs.append(v)
        return vecs
