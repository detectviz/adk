
# -*- coding: utf-8 -*-
# PostgreSQL 持久化樣板：與 SQLite 介面一致，便於後續替換。
from __future__ import annotations
from typing import Any, Dict, List, Optional
try:
    import psycopg
except Exception:
    psycopg = None

class PgDatabase:
    def __init__(self, dsn: str):
        if psycopg is None:
            raise RuntimeError("未安裝 psycopg，請先安裝再使用 PostgreSQL 持久化")
        self.conn = psycopg.connect(dsn, autocommit=True)
        self._init_schema()

    def _init_schema(self):
        with self.conn.cursor() as cur:
            cur.execute("""
            CREATE TABLE IF NOT EXISTS decisions(
              id BIGSERIAL PRIMARY KEY,
              session_id TEXT NOT NULL,
              agent_name TEXT NOT NULL,
              decision_type TEXT NOT NULL,
              input JSONB NOT NULL,
              output JSONB NOT NULL,
              confidence REAL,
              execution_time_ms INT,
              created_at TIMESTAMPTZ DEFAULT NOW()
            );
            """)

    # TODO: 其餘表與介面可參考 SQLite 版本擴充
