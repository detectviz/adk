
# -*- coding: utf-8 -*-
# FastAPI 伺服器：健康檢查、對話、HITL、RAG、回放/重跑、工具清單/規格、OpenAPI 安全宣告。
from __future__ import annotations
from fastapi import FastAPI, HTTPException, Header, Depends, Query
from fastapi.responses import Response
from pydantic import BaseModel
from ..core.assistant import SREAssistant
from ...adk_runtime.main import build_registry
from ..core.hitl import APPROVALS
from ..core.auth import require_api_key, require_role, AuthError
from ..core.rag import rag_create_entry, rag_update_status, rag_retrieve_tool
from ..core.debounce import DEBOUNCER
from ..core.persistence import DB
from ..core.replay import parse_steps, get_decision
from ..core.slo_guard import SLOGuardian

app = FastAPI(title="SRE Assistant API")
registry = build_registry()
assistant = SREAssistant(registry)
slo_guard = SLOGuardian(p95_ms=30000)

def auth_dep(x_api_key: str = Header(default="", alias="X-API-Key")) -> str:
    try:
        return require_api_key(x_api_key)
    except AuthError as e:
        raise HTTPException(status_code=401 if str(e)=="invalid api key" else 429, detail=str(e))

class ChatRequest(BaseModel):
    message: str
    session_id: str | None = None

@app.get("/health/live")
def health_live():
    return {"ok": True}

@app.get("/health/ready")
def health_ready():
    try:
        DB.list_decisions(limit=1)
        return {"ok": True, "db": "ready"}
    except Exception as e:
        raise HTTPException(status_code=503, detail=f"db not ready: {e}")

@app.post("/api/v1/chat")
async def chat(req: ChatRequest, role: str = Depends(auth_dep)):
    # Session-aware 去抖
    if not DEBOUNCER.allow_msg(req.message, req.session_id):
        raise HTTPException(status_code=409, detail="debounced")
    res = await assistant.chat(req.message)
    adv = slo_guard.evaluate(res["metrics"]["duration_ms"])
    res["slo_advice"] = adv.__dict__
    return res

class ApprovalDecision(BaseModel):
    status: str  # approved | denied
    decided_by: str
    reason: str | None = None

@app.get("/api/v1/approvals/{aid}")
def get_approval(aid: int, role: str = Depends(auth_dep)):
    a = APPROVALS.get(aid)
    if not a: raise HTTPException(status_code=404, detail="not found")
    return a.__dict__

@app.post("/api/v1/approvals/{aid}/decision")
def decide_approval(aid: int, body: ApprovalDecision, role: str = Depends(auth_dep)):
    if not require_role(role, "operator"):
        raise HTTPException(status_code=403, detail="forbidden")
    if body.status not in {"approved","denied"}:
        raise HTTPException(status_code=400, detail="invalid status")
    a = APPROVALS.decide(aid, status=body.status, decided_by=body.decided_by, reason=body.reason)
    return a.__dict__

@app.post("/api/v1/approvals/{aid}/execute")
async def execute_approval(aid: int, role: str = Depends(auth_dep)):
    if not require_role(role, "operator"):
        raise HTTPException(status_code=403, detail="forbidden")
    res = await assistant.execute_approval(aid)
    if not res.get("ok"):
        raise HTTPException(status_code=400, detail=res)
    return res

# RAG 管理與檢索
class RagCreate(BaseModel):
    title: str
    content: str
    tags: list[str] | None = None
@app.post("/api/v1/rag/entries")
def create_rag_entry(body: RagCreate, role: str = Depends(auth_dep)):
    if not require_role(role, "admin"):
        raise HTTPException(status_code=403, detail="forbidden")
    e = rag_create_entry(body.title, body.content, author="api", tags=body.tags or [], status="draft")
    return {"ok": True, "entry": e}

class RagApprove(BaseModel):
    status: str  # draft|approved|archived
@app.post("/api/v1/rag/entries/{entry_id}/status")
def set_rag_status(entry_id: int, body: RagApprove, role: str = Depends(auth_dep)):
    if not require_role(role, "admin"):
        raise HTTPException(status_code=403, detail="forbidden")
    e = rag_update_status(entry_id, body.status)
    if not e: raise HTTPException(status_code=404, detail="not found")
    return {"ok": True, "entry": e}

class RagQuery(BaseModel):
    query: str
    top_k: int = 5
    status_filter: list[str] | None = None
@app.post("/api/v1/rag/retrieve")
def rag_retrieve(body: RagQuery, role: str = Depends(auth_dep)):
    return rag_retrieve_tool(body.query, top_k=body.top_k, status_filter=body.status_filter)

# 回放與重跑
@app.get("/api/v1/decisions")
def list_decisions(limit: int = Query(20, ge=1, le=200), offset: int = Query(0, ge=0), role: str = Depends(auth_dep)):
    if not require_role(role, "viewer"):
        raise HTTPException(status_code=403, detail="forbidden")
    return {"items": DB.list_decisions(limit=limit, offset=offset)}

@app.get("/api/v1/tool-executions")
def list_tool_execs(limit: int = Query(20, ge=1, le=200), offset: int = Query(0, ge=0), role: str = Depends(auth_dep)):
    if not require_role(role, "viewer"):
        raise HTTPException(status_code=403, detail="forbidden")
    return {"items": DB.list_tool_execs(limit=limit, offset=offset)}

class ReplayRequest(BaseModel):
    decision_id: int

@app.post("/api/v1/replay")
async def replay(body: ReplayRequest, role: str = Depends(auth_dep)):
    if not require_role(role, "operator"):
        raise HTTPException(status_code=403, detail="forbidden")
    dec = get_decision(body.decision_id)
    if not dec:
        raise HTTPException(status_code=404, detail="decision not found")
    steps = parse_steps(dec["input"])
    import uuid, time, json
    new_id = DB.insert_decision(str(uuid.uuid4()), "SREAssistant", "replay", dec["input"], "[]", None, 0)
    t0 = time.time()
    results = await assistant._execute_steps(new_id, steps)
    dt = int((time.time()-t0)*1000)
    DB.update_decision_output(new_id, json.dumps([r.model_dump() for r in results], ensure_ascii=False), execution_time_ms=dt)
    return {"ok": True, "new_decision_id": new_id, "duration_ms": dt}

# 工具清單與規格查詢
@app.get("/api/v1/tools")
def list_tools(role: str = Depends(auth_dep)):
    tools = []
    for name, entry in registry.list_tools().items():
        spec = entry.get("spec", {})
        tools.append({
            "name": name,
            "require_approval": bool(spec.get("require_approval", False)),
            "risk_level": spec.get("risk_level", "Low"),
            "idempotent": bool(spec.get("idempotent", True)),
            "timeout_seconds": int(spec.get("timeout_seconds", 0))
        })
    return {"items": tools}

@app.get("/api/v1/tools/{name}/spec")
def tool_spec(name: str, role: str = Depends(auth_dep)):
    try:
        entry = registry.require(name)
        return {"name": name, "spec": entry["spec"]}
    except Exception:
        raise HTTPException(status_code=404, detail="tool not found")

# --- OpenAPI 安全宣告（API Key Header）---
def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema
    openapi_schema = app.openapi()
    openapi_schema.setdefault("components", {}).setdefault("securitySchemes", {})["ApiKeyHeader"] = {
        "type": "apiKey", "in": "header", "name": "X-API-Key"
    }
    # 對所有路徑套用安全需求（可視需要細分）
    for path in openapi_schema.get("paths", {}).values():
        for method in path.values():
            if isinstance(method, dict):
                method.setdefault("security", [{"ApiKeyHeader": []}])
    app.openapi_schema = openapi_schema
    return app.openapi_schema

app.openapi = custom_openapi
