
# ADK 全面替換說明

本版本以 **Google ADK** 物件作為唯一協調器實作：
- 頂層：`LoopAgent + BuiltInPlanner`
- 主代理：`LlmAgent(SREMainAgent)`
- 子專家：`LlmAgent` 綁定為 `AgentTool`
- 工具：`FunctionTool` 顯式定義 I/O（Pydantic）
- RAG：優先 `VertexAiRagRetrieval`，無 `RAG_CORPUS` 時回退 pgvector 工具

## 依賴
- `google-adk` 與 `google-genai`（提供 `VertexAiRagRetrieval` 與 `RagResource`）
- 既有外部系統依賴（Prometheus、Grafana、K8s、PostgreSQL+pgvector）

## 主要檔案
- `sre_assistant/adk_app/coordinator.py`: ADK 協調器組態
- `sre_assistant/server/app.py`: API 端點改用 ADK 協調器

## 遷移要點
- 原先 YAML+Registry 模式不再於 runtime 使用；仍可保留 YAML 作為工具文件描述。
- 若未安裝 ADK，API 將無法啟動；請於部署環境安裝授權套件。


## 子代理唯一掛載規則
- 依 ADK API 說明：同一個 agent 實例只能作為 sub-agent 掛載一次。若需在多處使用，請建立等配置但不同名稱的新實例。
- 本版已調整：`LoopAgent.agents` 僅包含 `main_llm`；子專家僅透過 `AgentTool` 由 `main_llm` 使用，避免重複掛載。
