
# -*- coding: utf-8 -*-
# FastAPI 伺服器：全面改用 ADK 協調器（LoopAgent+Planner）。
from __future__ import annotations
from fastapi import FastAPI, HTTPException, Header, Depends, Query
from pydantic import BaseModel
from ..core.telemetry import init_tracing
init_tracing()

from ..adk_app.coordinator import run_chat  # 以 ADK 協調器執行對話
from ..core.auth import require_api_key, require_role, AuthError
from ..core.debounce import DEBOUNCER
from ..core.persistence import DB
from ..core.slo_guard import SLOGuardian
from ..core.hitl import APPROVALS
from ..core.rag import rag_create_entry, rag_update_status, rag_retrieve_tool

app = FastAPI(title="SRE Assistant API (ADK)")
slo_guard = SLOGuardian(p95_ms=30000)

def auth_dep(x_api_key: str = Header(default="", alias="X-API-Key")) -> str:
    try:
        return require_api_key(x_api_key)
    except AuthError as e:
        raise HTTPException(status_code=401 if str(e)=="invalid api key" else 429, detail=str(e))

class ChatRequest(BaseModel):
    message: str
    session_id: str | None = None

@app.get("/health/live")
def health_live():
    return {"ok": True}

@app.get("/health/ready")
def health_ready():
    try:
        DB.list_decisions(limit=1)
        return {"ok": True, "db": "ready"}
    except Exception as e:
        raise HTTPException(status_code=503, detail=f"db not ready: {e}")

@app.post("/api/v1/chat")
async def chat(req: ChatRequest, role: str = Depends(auth_dep)):
    if not DEBOUNCER.allow_msg(req.message, req.session_id):
        raise HTTPException(status_code=409, detail="debounced")
    res = run_chat(req.message)
    adv = slo_guard.evaluate(res["metrics"]["duration_ms"])
    res["slo_advice"] = adv.__dict__
    return res

# 其餘端點（approvals, rag, decisions, replay, tools）保留既有實作或可於後續統一 ADK 事件模型
# 為了簡潔，此處省略，沿用 v12 版本對應檔案（若路由缺失請參照 v12 版）。
