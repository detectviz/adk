
# -*- coding: utf-8 -*-
# 追蹤套件：若環境有安裝 OpenTelemetry，則建立 Tracer；否則回傳 no-op。
from __future__ import annotations
from contextlib import contextmanager
from typing import Dict

try:
    from opentelemetry import trace
    from opentelemetry.trace import Status, StatusCode
    _TRACER = trace.get_tracer("sre-assistant")
except Exception:
    trace = None
    _TRACER = None

@contextmanager
def start_span(name: str, attrs: Dict[str, str] | None = None):
    """
    開啟一個追蹤 span 的情境管理器。若無 OTel 則為 no-op。
    參數:
      - name: span 名稱
      - attrs: 附加屬性（會做輕量摘要）
    """
    if _TRACER is None:
        yield None
        return
    span = _TRACER.start_span(name=name)
    if attrs:
        try:
            for k, v in list(attrs.items())[:20]:
                span.set_attribute(k, str(v)[:256])
        except Exception:
            pass
    try:
        yield span
        span.set_status(Status(StatusCode.OK))
    except Exception as e:
        span.set_status(Status(StatusCode.ERROR, str(e)))
        span.record_exception(e)
        raise
    finally:
        span.end()
